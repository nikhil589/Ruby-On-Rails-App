class CustomersController < ApplicationController
  def index
  	@customer = Customer.all
  end
  def new
  	@customer= Customer.new
  end
  def create
  	@customer= Customer.new(customer_params)

  	if @customer.save
  		flash[:notice] = "Added new record successfully"
  		redirect_to action:"index"
  	else
  		flash[:notice]= "Not successfull"
  		render action: "new"
  	end
  end

  private
  def customer_params
  	params.require(:customer).permit(:name,:gender)
  end
end
